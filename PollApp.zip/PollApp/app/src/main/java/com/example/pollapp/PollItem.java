package com.example.pollapp;

public class PollItem {
    private int imageResource;
    private String pollTitle, numQuestions;

    public PollItem(int imageResource, String pollTitle, String numQuestions) {
        this.imageResource = imageResource;
        this.pollTitle = pollTitle;
        this.numQuestions = numQuestions;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getPollTitle() {
        return pollTitle;
    }

    public String getNumQuestions() {
        return numQuestions;
    }
}
