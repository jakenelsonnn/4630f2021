package com.example.pollapp;

public class PollAnswer {
    private String answerText;
    private int numResponses;

    public PollAnswer(String answerText){
        this.answerText = answerText;
        numResponses = 0;
    }

    public String getAnswerText() {
        return answerText;
    }

    public int getNumResponses() {
        return numResponses;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }

    public void setNumResponses(int numResponses){
        this.numResponses = numResponses;
    }

    public void incrementNumResponses(){
        numResponses++;
    }
}
