package com.example.pollapp;

import java.util.ArrayList;

public class PollQuestion {
    private String questionText;
    private ArrayList<PollAnswer> answers;

    public PollQuestion(String questionText, ArrayList<String> answers){
        this.answers = new ArrayList<>();
        this.questionText = questionText;

        for(int i = 0; i < answers.size(); i++){
            String answer = answers.get(i);
            this.answers.add(new PollAnswer(answer));
        }
    }

    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public ArrayList<PollAnswer> getAnswers(){
        return this.answers;
    }
}
