package com.example.pollapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyPollsFragment extends Fragment {

    private RecyclerView pollRecyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_polls, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState){
        //create list of polls for home screen
        ArrayList<PollItem> pollItemArrayList = new ArrayList<>();

        //filling with placeholder data
        for(int i = 1; i < 20; i++){
            pollItemArrayList.add(new PollItem(R.drawable.pollmenuicon, "Survey Title " + i, "Number of Questions: "));
        }

        //configure recyclerview layout manager and adapter
        pollRecyclerView = (RecyclerView) getActivity().findViewById(R.id.pollsRecyclerView);
        pollRecyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(getContext());
        adapter = new PollListAdapter(pollItemArrayList);

        pollRecyclerView.setLayoutManager(layoutManager);
        pollRecyclerView.setAdapter(adapter);
    }
}
