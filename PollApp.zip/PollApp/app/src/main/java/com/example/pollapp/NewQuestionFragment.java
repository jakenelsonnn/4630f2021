package com.example.pollapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class NewQuestionFragment extends Fragment implements View.OnClickListener {

    private RecyclerView answersRecyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<NewAnswerItem> answerItemArrayList = new ArrayList<>();
    private View rootView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.new_question_item, container, false);
        FloatingActionButton fab = rootView.findViewById(R.id.new_answer_button);
        fab.setOnClickListener(this);
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        answerItemArrayList.add(new NewAnswerItem());

        //configure recyclerview layout manager and adapter
        answersRecyclerView = (RecyclerView) getActivity().findViewById(R.id.answers_recyclerview);
        answersRecyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(getContext());
        adapter = new AnswerListAdapter(answerItemArrayList);

        answersRecyclerView.setLayoutManager(layoutManager);
        answersRecyclerView.setAdapter(adapter);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.new_answer_button:
                Toast.makeText(this.getContext(), "hey", Toast.LENGTH_SHORT).show();
                int numAnswers = answerItemArrayList.size();
                answerItemArrayList.add(new NewAnswerItem());
                answersRecyclerView.getAdapter().notifyItemInserted(numAnswers);
                answersRecyclerView.smoothScrollToPosition(numAnswers);
                break;
        }
    }
}
