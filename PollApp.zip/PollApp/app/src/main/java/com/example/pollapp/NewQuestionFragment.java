package com.example.pollapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class NewQuestionFragment extends Fragment {

    private RecyclerView answersRecyclerView;
    private RecyclerView.Adapter answerAdapter;
    private RecyclerView.LayoutManager answerLayoutManager;
    private ArrayList<NewAnswerItem> answerItemArrayList = new ArrayList<>();

    private View rootView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.new_question_item, container, false);
        TextView newAnswerButton = (TextView) rootView.findViewById(R.id.new_answer_button);
        newAnswerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "new answer", Toast.LENGTH_SHORT).show();
                int numAnswers = answerItemArrayList.size();
                answerItemArrayList.add(new NewAnswerItem());
                answersRecyclerView.getAdapter().notifyItemInserted(numAnswers);
                answersRecyclerView.smoothScrollToPosition(numAnswers);
            }
        });
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //create initial answer EditText
        answerItemArrayList.add(new NewAnswerItem());

        //configure recyclerview layout manager and adapter
        answersRecyclerView = (RecyclerView) rootView.findViewById(R.id.answers_recyclerview);
        answersRecyclerView.setHasFixedSize(true);

        answerLayoutManager = new LinearLayoutManager(getContext());
        answerAdapter = new AnswerListAdapter(answerItemArrayList);

        answersRecyclerView.setLayoutManager(answerLayoutManager);
        answersRecyclerView.setAdapter(answerAdapter);
    }

    //currently unused, but still may need
    public void newAnswer(View view) {
        Toast.makeText(getContext(), "new answer", Toast.LENGTH_SHORT).show();
        int numAnswers = answerItemArrayList.size();
        answerItemArrayList.add(new NewAnswerItem());
        answersRecyclerView.getAdapter().notifyItemInserted(numAnswers);
        answersRecyclerView.smoothScrollToPosition(numAnswers);
    }
}
