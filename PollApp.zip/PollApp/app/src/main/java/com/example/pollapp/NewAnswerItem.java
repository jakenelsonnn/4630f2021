package com.example.pollapp;

public class NewAnswerItem {

    private String answerText;

    public NewAnswerItem() {}

    public NewAnswerItem(String answerText){
        this.answerText = answerText;
    }

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }
}
