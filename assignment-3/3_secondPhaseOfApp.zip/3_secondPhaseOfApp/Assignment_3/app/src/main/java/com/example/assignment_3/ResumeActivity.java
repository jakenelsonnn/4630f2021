package com.example.assignment_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class ResumeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resume);
    }

    public void openResume(View v){
        Uri uri = Uri.parse("https://github.com/jakenelsonnn/4630f2021/blob/main/assignment-3/resume.pdf");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public void launchFinalActivity(View v) {
        Intent i = new Intent(this, FinalActivity.class);
        startActivity(i);
    }
}