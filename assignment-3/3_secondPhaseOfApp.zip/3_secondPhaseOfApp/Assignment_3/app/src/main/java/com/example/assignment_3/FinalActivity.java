package com.example.assignment_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class FinalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
    }

    public void complimentMessage(View v){
        EditText textBox = findViewById(R.id.editText);
        textBox.getText().clear();
        Toast.makeText(this, "Wow! Thank you so much.", Toast.LENGTH_LONG).show();
    }
}