package com.example.assignment_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class InvestmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_investment);
    }

    public void alertSecret(View v) {
        Toast.makeText(this, "These investments are fake! :)", Toast.LENGTH_LONG).show();
    }

    public void launchOtherFactsActivity(View v) {
        Intent i = new Intent(this, ResumeActivity.class);
        startActivity(i);
    }
}