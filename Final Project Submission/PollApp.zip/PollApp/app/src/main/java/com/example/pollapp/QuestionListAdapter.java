package com.example.pollapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class QuestionListAdapter extends RecyclerView.Adapter<QuestionListAdapter.QuestionViewHolder> {

    public static class QuestionViewHolder extends RecyclerView.ViewHolder {

        public EditText questionTitleEditText;

        public QuestionViewHolder(@NonNull View itemView){
            super(itemView);
            this.questionTitleEditText = itemView.findViewById(R.id.question_title_edittext);
        }

    }

    private ArrayList<NewQuestionItem> newQuestionItemArrayList;

    public QuestionListAdapter(ArrayList<NewQuestionItem> newQuestionItemArrayList) {
        this.newQuestionItemArrayList = newQuestionItemArrayList;
    }

    @NonNull
    @Override
    public QuestionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.new_question_item, parent, false);
        return new QuestionViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull QuestionViewHolder holder, int position) {
        NewQuestionItem currentQuestionItem = newQuestionItemArrayList.get(position);
        holder.questionTitleEditText.setText(currentQuestionItem.getQuestionTitle());
    }

    @Override
    public int getItemCount() {
        if(newQuestionItemArrayList == null){
            return 0;
        }else{
            return newQuestionItemArrayList.size();
        }
    }
}
