package com.example.pollapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class NewPollFragment extends Fragment {

    private RecyclerView questionsRecyclerView;
    private QuestionListAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<NewQuestionItem> questionItemArrayList = new ArrayList<>();

    private View rootView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_new_poll, container, false);
        Button button = (Button) rootView.findViewById(R.id.new_question_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int numQuestions = questionItemArrayList.size();
                questionItemArrayList.add(new NewQuestionItem());
                questionsRecyclerView.getAdapter().notifyItemInserted(numQuestions);
                questionsRecyclerView.smoothScrollToPosition(numQuestions);
            }
        });
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        questionItemArrayList.add(new NewQuestionItem());

        //configure recyclerview layout manager and adapter
        questionsRecyclerView = (RecyclerView) rootView.findViewById(R.id.new_question_recyclerview);
        questionsRecyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(getContext());
        adapter = new QuestionListAdapter(questionItemArrayList);

        questionsRecyclerView.setLayoutManager(layoutManager);
        questionsRecyclerView.setAdapter(adapter);
    }
}
