package com.example.pollapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AnswerListAdapter extends RecyclerView.Adapter<AnswerListAdapter.AnswerViewHolder> {

    public static class AnswerViewHolder extends RecyclerView.ViewHolder {

        public EditText answerEditText;

        public AnswerViewHolder(@NonNull View itemView) {
            super(itemView);
            this.answerEditText = itemView.findViewById(R.id.new_answer_edittext);
        }
    }

    private ArrayList<NewAnswerItem> newAnswerItemArrayList;

    public AnswerListAdapter(ArrayList<NewAnswerItem> newAnswerItemArrayList) {
        this.newAnswerItemArrayList = newAnswerItemArrayList;
    }

    @NonNull
    @Override
    public AnswerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.new_answer_item, parent, false);
        return new AnswerViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AnswerViewHolder holder, int position) {
        NewAnswerItem currentAnswerItem = newAnswerItemArrayList.get(position);
        holder.answerEditText.setText(currentAnswerItem.getAnswerText());
    }

    @Override
    public int getItemCount() {
        if(newAnswerItemArrayList == null){
            return 0;
        }else{
            return newAnswerItemArrayList.size();
        }
    }

}
