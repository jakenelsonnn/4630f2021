package com.example.pollapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PollListAdapter extends RecyclerView.Adapter<PollListAdapter.PollViewHolder> {

    public static class PollViewHolder extends RecyclerView.ViewHolder {

        public ImageView pollIcon;
        public TextView pollTitle, numQuestions;

        public PollViewHolder(View itemView) {
            super(itemView);
            pollIcon = itemView.findViewById(R.id.poll_card_icon);
            pollTitle = itemView.findViewById(R.id.poll_card_title);
            numQuestions = itemView.findViewById(R.id.poll_card_question_number);

        }
    }

    private ArrayList<PollItem> pollItemArrayList;

    public PollListAdapter(ArrayList<PollItem> pollItems){
        pollItemArrayList = pollItems;
    }

    //give the poll_item.xml layout to the ViewHolder
    @NonNull
    @Override
    public PollViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.poll_item, parent, false);
        return new PollViewHolder(v);
    }

    //assign attributes to the views in the ViewHolder from the pollItemArrayList
    @Override
    public void onBindViewHolder(@NonNull PollViewHolder holder, int position) {
        PollItem currentPollItem = pollItemArrayList.get(position);
        holder.pollIcon.setImageResource(currentPollItem.getImageResource());
        holder.pollTitle.setText(currentPollItem.getPollTitle());
        holder.numQuestions.setText(currentPollItem.getNumQuestions());
    }

    @Override
    public int getItemCount() {
        if(pollItemArrayList == null){
            return 0;
        }else{
            return pollItemArrayList.size();
        }
    }
}
