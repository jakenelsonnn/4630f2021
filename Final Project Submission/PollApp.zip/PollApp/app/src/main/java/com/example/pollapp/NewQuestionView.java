package com.example.pollapp;

import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class NewQuestionView extends ConstraintLayout {

    private RecyclerView answersRecyclerView;
    private AnswerListAdapter answerAdapter;
    private RecyclerView.LayoutManager answerLayoutManager;
    private ArrayList<NewAnswerItem> answerItemArrayList = new ArrayList<>();

    private View rootView;

    public NewQuestionView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        LayoutInflater inflater = LayoutInflater.from(context);
        inflater.inflate(R.layout.new_question_item, this);
    }

    @Nullable
    @Override
    public void onFinishInflate() {
        super.onFinishInflate();
        TextView newAnswerButton = (TextView) rootView.findViewById(R.id.new_answer_button);
        newAnswerButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(), "new answer", Toast.LENGTH_SHORT).show();
                int numAnswers = answerItemArrayList.size();
                answerItemArrayList.add(new NewAnswerItem());
                answersRecyclerView.getAdapter().notifyItemInserted(numAnswers);
                answersRecyclerView.smoothScrollToPosition(numAnswers);
            }
        });
        //create initial answer EditText
        answerItemArrayList.add(new NewAnswerItem());

        //configure recyclerview layout manager and adapter
        answersRecyclerView = (RecyclerView) rootView.findViewById(R.id.answers_recyclerview);
        answersRecyclerView.setHasFixedSize(true);

        answerLayoutManager = new LinearLayoutManager(getContext());
        answerAdapter = new AnswerListAdapter(answerItemArrayList);

        answersRecyclerView.setLayoutManager(answerLayoutManager);
        answersRecyclerView.setAdapter(answerAdapter);
    }

    //currently unused, but still may need
    public void newAnswer(View view) {
        Toast.makeText(getContext(), "new answer", Toast.LENGTH_SHORT).show();
        int numAnswers = answerItemArrayList.size();
        answerItemArrayList.add(new NewAnswerItem());
        answersRecyclerView.getAdapter().notifyItemInserted(numAnswers);
        answersRecyclerView.smoothScrollToPosition(numAnswers);
    }
}
