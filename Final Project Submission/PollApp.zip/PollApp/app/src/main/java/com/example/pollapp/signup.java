package com.example.pollapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class signup extends AppCompatActivity {

    EditText email, password, password_confirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        email = findViewById(R.id.signupemail);
        password = findViewById(R.id.signuppassword);
        password_confirm = findViewById(R.id.signuppasswordconfirm);
    }

    public void launchHome(View view) {

        String email_string, pass_string, pass_confirm_string;
        email_string = email.getText().toString();
        pass_string = password.getText().toString();
        pass_confirm_string = password_confirm.getText().toString();

        //check if password and password_confirm match
        if(!pass_string.equals(pass_confirm_string)){
            Toast.makeText(getApplicationContext(), "The passwords do not match!", Toast.LENGTH_SHORT).show();
            return;
        }

        //create user entity
        UserEntity newUser = new UserEntity();
        newUser.setEmail(email_string);
        newUser.setPassword(pass_string);

        //validate user and insert user into database
        if(validateUserInput(newUser)){
            UserDatabase userDatabase = UserDatabase.getUserDatabase(getApplicationContext());
            UserDao userDao = userDatabase.userDao();
            new Thread(new Runnable(){
                @Override
                public void run() {
                    userDao.registerUser(newUser);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Account created successfully.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }).start();

            Intent i = new Intent(this, HomeActivity.class);
            //send over email string to next activity
            i.putExtra("email", email_string);
            startActivity(i);

        }else {
            Toast.makeText(getApplicationContext(), "Please fill out all required fields.", Toast.LENGTH_SHORT).show();
        }
    }

    //to ensure no empty fields
    private Boolean validateUserInput(UserEntity userEntity){
        if(userEntity.getEmail().isEmpty() || userEntity.getPassword().isEmpty()){
            return false;
        }
        return true;
    }
}