package com.example.pollapp;

public class NewQuestionItem {

    private String questionTitle;

    public NewQuestionItem() {}

    public NewQuestionItem(String questionTitle){
        this.questionTitle = questionTitle;
    }

    public String getQuestionTitle() {
        return questionTitle;
    }

    public void setQuestionTitle(String questionTitle) {
        this.questionTitle = questionTitle;
    }
}
