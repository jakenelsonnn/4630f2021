package com.example.pollapp;

import java.util.ArrayList;
import java.util.UUID;

public class Poll {
    private String pollID;
    private String pollTitle;
    private ArrayList<PollQuestion> pollQuestions;

    public Poll(String pollTitle, ArrayList<PollQuestion> pollQuestions){
        this.pollTitle = pollTitle;
        this.pollQuestions = pollQuestions;
        this.pollID = generateID();
    }

    public String generateID(){
        String id = UUID.randomUUID().toString();
        id.replace("-", "");
        return id;
    }

    public String getPollID() {
        return pollID;
    }

    public void setPollID(String pollID) {
        this.pollID = pollID;
    }

    public String getPollTitle() {
        return pollTitle;
    }

    public void setPollTitle(String pollTitle) {
        this.pollTitle = pollTitle;
    }

    public ArrayList<PollQuestion> getPollQuestions() {
        return pollQuestions;
    }

    public void setPollQuestions(ArrayList<PollQuestion> pollQuestions) {
        this.pollQuestions = pollQuestions;
    }
}
